import streamlit as st
from dotenv import load_dotenv
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from htmlTemplates import css
from googletrans import Translator
import base64
import requests
from bs4 import BeautifulSoup
from langchain.schema import HumanMessage, AIMessage
import pandas as pd
from pandasai import PandasAI
from pandasai.llm.openai import OpenAI

# Translator for language translation
translator = Translator()

# --- Define Custom CSS ---
def add_custom_css():
    st.markdown("""
    <style>
    .chat-container {
        background-color: #f1f1f1;
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 10px;
    }
    .user-message {
        background-color: #cce7ff;
        padding: 10px;
        border-radius: 10px;
        text-align: right;
    }
    .bot-message {
        background-color: #ffebcc;
        padding: 10px;
        border-radius: 10px;
        text-align: left;
    }
    html, body, [data-testid="stAppViewContainer"] {
        background-color: #FFFFFF;
    }
    h1 {
        font-family: 'Times New Roman', Times, serif;
        color: #1E2AE;
        font-size: 50px;
        text-align: center;
        margin-top: 20px;
    }
    .sidebar-title {
        font-size: 24px;
        font-weight: bold;
    }
    .sidebar-subtitle, .language-label, .ask-question-label {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
    }
    .file-uploader, .language-dropdown, .question-input {
        font-size: 16px;
    }
    </style>
    """, unsafe_allow_html=True)

# --- PDF Text Extraction ---
def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text() or ""
    return text

# --- URL Content Extraction ---
def get_text_from_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        return soup.get_text(separator='\n', strip=True)
    except Exception as e:
        st.error(f"Failed to retrieve content from URL: {e}")
        return None

# --- Text Splitting ---
def get_text_chunks(text):
    text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, chunk_overlap=200, length_function=len)
    return text_splitter.split_text(text)

# --- Vector Store Creation ---
def get_vectorstore(text_chunks):
    embeddings = OpenAIEmbeddings()
    return FAISS.from_texts(texts=text_chunks, embedding=embeddings)

# --- Conversational Retrieval Chain ---
def get_conversation_chain(vectorstore):
    llm = ChatOpenAI()
    memory = ConversationBufferMemory(memory_key='chat_history', return_messages=True)
    return ConversationalRetrievalChain.from_llm(llm=llm, retriever=vectorstore.as_retriever(), memory=memory)

# --- Bot Response Handling ---
def handle_userinput(user_question, selected_language):
    if st.session_state.conversation:
        response = st.session_state.conversation({'question': user_question})
        st.session_state.chat_history = response['chat_history']
        with st.container():
            for message in st.session_state.chat_history:
                if isinstance(message, HumanMessage):
                    st.markdown(f"<div class='user-message'>🤔 {message.content}</div>", unsafe_allow_html=True)
                elif isinstance(message, AIMessage):
                    translated_message = translator.translate(message.content, dest=selected_language).text
                    st.markdown(f"<div class='bot-message'>💡 {translated_message}</div>", unsafe_allow_html=True)

# --- Handle CSV Query with PandasAI ---
def handle_csv_query(query, selected_language):
    if "csv_data" in st.session_state and st.session_state.csv_data is not None:
        # Use PandasAI for chat-based interactions with CSV
        pandas_ai = PandasAI(OpenAI(api_token="sk-proj-CUpwYPrBDsqviA1JNK8VT3BlbkFJmlppurx81TGlHNRp6c2m"))  # Replace with your OpenAI API key
        response = pandas_ai.run(st.session_state.csv_data, prompt=query)
        translated_response = translator.translate(response, dest=selected_language).text
        st.markdown(f"<div class='bot-message'>💡 {translated_response}</div>", unsafe_allow_html=True)

# --- Display PDF in Streamlit ---
def displayPDF(uploaded_file, width=500, height=750):
    base64_pdf = base64.b64encode(uploaded_file.read()).decode('utf-8')
    pdf_display = f'<embed src="data:application/pdf;base64,{base64_pdf}" width={width} height={height} style="padding: 10px; border: 3px solid #5e5eff;" type="application/pdf">'
    return pdf_display

# --- Main Application ---
def main():
    load_dotenv()
    st.set_page_config(page_title="Askify: Q/A Platform", layout="wide")
    add_custom_css()

    # Ensure session state variables are initialized
    if "conversation" not in st.session_state:
        st.session_state.conversation = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "csv_data" not in st.session_state:
        st.session_state.csv_data = None

    st.markdown("<h1>ASKIFY: Q/A Platform</h1>", unsafe_allow_html=True)
    
    # Sidebar for PDF, URL, and CSV Upload
    st.sidebar.markdown("<div class='sidebar-title'>Assistant</div>", unsafe_allow_html=True)
    st.sidebar.markdown("<div class='sidebar-subtitle'>Upload a PDF, CSV, or provide a URL:</div>", unsafe_allow_html=True)
    
    pdf_docs = st.sidebar.file_uploader("Upload PDFs", accept_multiple_files=True, type='pdf', key="file_uploader")
    website_url = st.sidebar.text_input("Or enter a URL", key="url_input")
    csv_file = st.sidebar.file_uploader("Upload CSV", type='csv', key="csv_uploader")

    if pdf_docs:
        for pdf in pdf_docs:
            st.sidebar.markdown(displayPDF(pdf), unsafe_allow_html=True)

    if csv_file:
        st.session_state.csv_data = pd.read_csv(csv_file)
        st.write("CSV Data Preview:")
        st.write(st.session_state.csv_data)

    if website_url:
        st.sidebar.markdown(f"**URL Content Preview:** {website_url}")

    if pdf_docs or website_url:
        if st.sidebar.button("Process"):
            with st.spinner("Processing..."):
                raw_text = get_pdf_text(pdf_docs) if pdf_docs else get_text_from_url(website_url)
                text_chunks = get_text_chunks(raw_text)
                vectorstore = get_vectorstore(text_chunks)
                st.session_state.conversation = get_conversation_chain(vectorstore)
            st.sidebar.success("Document/URL processed successfully!")

    # Language selection for translation
    st.markdown("<div class='language-label'>Select Language for Output Translation:</div>", unsafe_allow_html=True)
    languages = {'English': 'en', 'Spanish': 'es', 'French': 'fr', 'German': 'de', 'Chinese': 'zh-cn', 'Hindi': 'hi'}
    selected_language = st.selectbox("", options=list(languages.keys()), index=0, key="language_dropdown")

    # Ask a question input box
    st.markdown("<div class='ask-question-label'>Ask a question:</div>", unsafe_allow_html=True)
    query = st.text_input("", placeholder="Type your query...", key="query_input")

    if st.button("Send"):
        if query:
            if st.session_state.csv_data is not None:
                handle_csv_query(query, languages[selected_language])
            else:
                handle_userinput(query, languages[selected_language])

if __name__ == '__main__':
    main()
