import streamlit as st
from streamlit_chat import message
from dotenv import load_dotenv
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from htmlTemplates import css, bot_template, user_template
# from googletrans import Translator
from google_trans_new import google_translator
import base64
import requests
from bs4 import BeautifulSoup
import os
from langchain.schema import HumanMessage, AIMessage

# Translator for language translation
translator = google_translator()

# --- Define Custom CSS ---
def add_custom_css():
    st.markdown("""
    <style>
    .sidebar-title {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
    }
    .chat-container {
        background-color: #f1f1f1;
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 10px;
    }
    .user-message {
        background-color: #d9fdd3;
        padding: 10px;
        border-radius: 10px;
        text-align: right;
    }
    .bot-message {
        background-color: #ffedcc;
        padding: 10px;
        border-radius: 10px;
        text-align: left;
    }
    .pdf-preview {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin-top: 10px;
        background-color: #f9f9f9;
        max-height: 300px;
        overflow-y: auto;
    }
    .chat-input {
        margin-top: 10px;
    }
    html, body, [data-testid="stAppViewContainer"] {
        background-color: #FFFFFF;
    }
    h1 {
        font-family: 'Times New Roman', Times, serif;
        color: #1E2AE;
        font-size: 100px;
        text-align: center;
    }
    </style>
    """, unsafe_allow_html=True)

# --- PDF Text Extraction ---
def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text() or ""
    return text

def extract_text_from_pdf(pdf_file):
    reader = PdfReader(pdf_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text

# --- URL Content Extraction ---
def get_text_from_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        return soup.get_text(separator='\n', strip=True)
    except Exception as e:
        st.error(f"Failed to retrieve content from URL: {e}")
        return None

# --- Text Splitting ---
def get_text_chunks(text):
    text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, chunk_overlap=200, length_function=len)
    return text_splitter.split_text(text)

# --- Vector Store Creation ---
def get_vectorstore(text_chunks):
    embeddings = OpenAIEmbeddings()
    return FAISS.from_texts(texts=text_chunks, embedding=embeddings)

# --- Conversational Retrieval Chain ---
def get_conversation_chain(vectorstore):
    llm = ChatOpenAI(temperature=0)
    memory = ConversationBufferMemory(memory_key='chat_history', return_messages=True)
    
    # Conversational retrieval chain
    return ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=vectorstore.as_retriever(),
        memory=memory
    )


# --- Display PDF in Streamlit ---
def displayPDF(uploaded_file, width=500, height=750):
    base64_pdf = base64.b64encode(uploaded_file.read()).decode('utf-8')
    pdf_display = f'<embed src="data:application/pdf;base64,{base64_pdf}" width={width} height={height} style="padding: 10px; border: 3px solid #5e5eff;" type="application/pdf">'
    return pdf_display

def handle_userinput(user_question):
    # Ensure conversation chain exists
    if st.session_state.conversation:
        
        # Append user question as HumanMessage
        st.session_state.chat_history.append(HumanMessage(content=user_question))
        
        # Call conversation chain and get the response
        response = st.session_state.conversation({"question": user_question, "chat_history": st.session_state.chat_history})
        
        # Append bot response as AIMessage
        bot_reply = response['answer']  # Assuming response returns 'answer' from the chain
        st.session_state.chat_history.append(AIMessage(content=bot_reply))
        
        # Display messages correctly
        for message in st.session_state.chat_history:
            if isinstance(message, HumanMessage):
                st.write(user_template.replace("{{MSG}}", message.content), unsafe_allow_html=True)
            elif isinstance(message, AIMessage):
                st.write(bot_template.replace("{{MSG}}", message.content), unsafe_allow_html=True)

                
# --- Main Application ---
def main():
    load_dotenv()
    st.set_page_config(page_title="Askify: Q/A Platform", layout="wide")
    add_custom_css()

    # Initialize Streamlit session state variables
    if "conversation" not in st.session_state:
        st.session_state.conversation = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    

    
    st.markdown("<h1>ASKIFY: Q/A Platform</h1>", unsafe_allow_html=True)
    
    st.sidebar.title("PDF Assistant")
    st.sidebar.markdown("### Upload a PDF or provide a URL:")
    pdf_docs = st.sidebar.file_uploader("Upload PDFs", accept_multiple_files=True, type='pdf')
    website_url = st.sidebar.text_input("Or enter a URL")

    # Display PDF Preview in Sidebar
    if pdf_docs:
        for pdf in pdf_docs:
            st.sidebar.markdown(displayPDF(pdf), unsafe_allow_html=True)
    
    if website_url:
        st.sidebar.markdown(f"**URL Content Preview:** {website_url}")

    if pdf_docs or website_url:
        if st.sidebar.button("Process"):
            with st.spinner("Processing..."):
                raw_text = get_pdf_text(pdf_docs) if pdf_docs else get_text_from_url(website_url)
                text_chunks = get_text_chunks(raw_text)
                vectorstore = get_vectorstore(text_chunks)
                st.session_state.conversation = get_conversation_chain(vectorstore)
            st.sidebar.success("Document/URL processed successfully!")

    st.header("Chat with your document 🤖")
    query = st.text_input("Ask a question:", placeholder="Type your query...", key="query")

    if query:
        st.session_state.chat_history.append({"role": "user", "content": query})
        response = st.session_state.conversation({'question': query})
        st.session_state.chat_history = response['chat_history']

        # Display messages
        for i, msg in enumerate(st.session_state.chat_history[1:]):
            if i % 2 == 0:
                message(msg.content, is_user=True, key=f"user_{i}")
            else:
                message(msg.content, is_user=False, key=f"bot_{i}")

if __name__ == '__main__':
    main()
